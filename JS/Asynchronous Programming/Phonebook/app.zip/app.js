function attachEvents() {
    const buttonCreateContact = document.getElementById('btnCreate');
    const buttonLoadContacts = document.getElementById('btnLoad');

    const baseUrl = 'http://localhost:3030/jsonstore/phonebook/';
    
    buttonCreateContact.addEventListener('click', createContact);
    buttonLoadContacts.addEventListener('click', loadContacts);
    
    function createContact() {
        const inputPhone = buttonCreateContact.previousElementSibling.previousElementSibling;
        const inputPerson = inputPhone.previousElementSibling.previousElementSibling;

        const person = inputPerson.value;
        const phone = inputPhone.value;

        fetch(baseUrl, {
            'method': 'POST',
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': JSON.stringify({person, phone})
        })
            .then(loadContacts)
            .catch()
    }

    function loadContacts() {
        fetch(baseUrl)
            .then(p => p.json())
            .then(processContacts)
            .catch()

        function processContacts(data) {
            const ulPhonebook = buttonLoadContacts.previousElementSibling;
            ulPhonebook.textContent = '';

            data = Object.values(data);

            for (const contact of data) {
                const li = document.createElement('li');
                li.textContent = `${contact.person}: ${contact.phone}`;
                li.dataset.id = contact._id;

                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Delete';
                deleteButton.addEventListener('click', deleteContact);
                li.appendChild(deleteButton);

                ulPhonebook.appendChild(li);
            }
        }

        function deleteContact(e) {
            const liContact = e.target.parentNode;

            fetch(baseUrl + liContact.dataset.id, {
                'method': 'DELETE',
            })
                .catch()
        }
    }
}

attachEvents();